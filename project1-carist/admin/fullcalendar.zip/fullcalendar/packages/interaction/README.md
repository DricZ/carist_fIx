
# FullCalendar Interaction Plugin

Provides functionality for event drag-n-drop, resizing, dateClick, and selectable actions

[View the docs &raquo;](https://fullcalendar.io/docs/editable)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
